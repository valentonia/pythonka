import turtle

turtle.penup()
picture = open('picture.txt', 'r').readlines()
for line in picture:
    if line in picture:
        if line == '\n':
            turtle.penup()
        else:
            nums = [int(x) for x in line.split(',')]
            turtle.goto(nums[0], nums[1])
            turtle.pendown()
