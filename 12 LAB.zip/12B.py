try:
    reader = open(input(), 'r')
    for row in reader:
        print(row)
    reader.close()
except FileNotFoundError:
    print('ERROR: File not found')