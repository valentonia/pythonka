found = False
myData = None
while True:
    try:
        myData = open(input('Enter a filenum: '), 'r').readlines()
        found = True
        break
    except FileNotFoundError:
        print('Error: Cannot open the file')

dict_file = open('dict.txt', 'r').read().split()
line_count = 1
for line in myData:
    for word in line.split():
        if '.' in word:
            word = word.replace('.','')
        elif ',' in word:
            word = word.replace(',','')
        search = word.upper()
        if search not in dict_file:
            print(f'Line {line_count}:', word)
    line_count += 1
