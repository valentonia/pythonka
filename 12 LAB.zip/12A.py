input_file = open('input.txt', 'r')
output_file = open('output.txt', 'w')

for line in input_file:
    line = line.capitalize()
    output_file.write(line)

input_file.close()
output_file.close()